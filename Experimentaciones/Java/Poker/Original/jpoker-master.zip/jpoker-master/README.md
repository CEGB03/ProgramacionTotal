[![License](http://img.shields.io/:license-gpl3-blue.svg)](http://www.gnu.org/licenses/gpl-3.0.html)
[![Build Status](https://travis-ci.org/dperezcabrera/jpoker.svg?branch=master)](https://travis-ci.org/dperezcabrera/jpoker)
[![Coverage Status](https://coveralls.io/repos/github/dperezcabrera/jpoker/badge.svg?branch=master)](https://coveralls.io/github/dperezcabrera/jpoker?branch=master)
[![GitHub issues](https://img.shields.io/github/issues-raw/dperezcabrera/jpoker.svg?maxAge=2592000)](https://github.com/dperezcabrera/jpoker/issues)

# JPoker

A simple poker game with gui.

[Manual](http://www.javahispano.org/portada/2015/2/2/nuevo-tutorial-desarrollando-con-java-8.html)

[Manual mobi](https://github.com/dperezcabrera/jpoker/blob/master/Desarrollando%20con%20Java%208:%20Poker.mobi)
[Manual epub](https://github.com/dperezcabrera/jpoker/blob/master/Desarrollando%20con%20Java%208:%20Poker.epub)
