public class main {
    public static void main(String[] args) {
        //Prueba prueba =new Prueba();
        System.out.println("A");
        Lista lista =new Lista();
        for (Equipo equipo : lista.getLista()) {
            System.out.println(equipo);
        }
        //prueba.toString();
    }
}
