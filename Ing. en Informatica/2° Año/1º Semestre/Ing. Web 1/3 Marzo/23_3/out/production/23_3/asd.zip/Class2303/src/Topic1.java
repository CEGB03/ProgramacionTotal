public class Topic1 {
    public static void main(String[] args) {
        var condition = false;
        if (condition) {
            System.out.println("The variable is true");
        } else {
            System.out.println("The variable is false");
        }
        
        var number = 3;
        var textNumber = "Unknown number";
        if (number == 1) {
            textNumber = "Number one";
        } else if (number == 2) {
            textNumber = "Number two";
        } else if (number == 3) {
            textNumber = "Number three";
        } else {
            textNumber = "Out of range";
        }
        System.out.println("textNumber = " + textNumber);
        
    }
}
