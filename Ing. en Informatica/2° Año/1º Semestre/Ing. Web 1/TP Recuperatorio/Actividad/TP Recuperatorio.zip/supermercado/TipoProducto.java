
/**
 * 
 * @author Emiliano Daniele 
 * @version 1.0
 */
public enum TipoProducto
{
    Arroz, Fideos, Jabon, Perfume, Carne, Verduras
}
