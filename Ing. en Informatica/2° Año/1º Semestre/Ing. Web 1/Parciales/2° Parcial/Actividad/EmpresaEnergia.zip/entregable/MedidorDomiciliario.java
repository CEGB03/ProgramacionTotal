
public class MedidorDomiciliario extends Medidor {
	// TODO Implementar la clase
}
