 


public enum TipoMedidor {
	COMERCIAL, DOMICILIARIO
}
