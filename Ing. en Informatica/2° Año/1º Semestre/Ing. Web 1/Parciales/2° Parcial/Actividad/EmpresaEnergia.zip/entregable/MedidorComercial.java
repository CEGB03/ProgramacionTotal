
public class MedidorComercial extends Medidor {
	// TODO Implementar la clase
}
