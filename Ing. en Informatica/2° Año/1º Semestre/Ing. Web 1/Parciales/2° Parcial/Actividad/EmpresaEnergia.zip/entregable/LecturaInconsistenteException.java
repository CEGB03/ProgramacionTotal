
public class LecturaInconsistenteException extends Exception {
	
	public LecturaInconsistenteException(String msg) {
		super(msg);
	}

}
