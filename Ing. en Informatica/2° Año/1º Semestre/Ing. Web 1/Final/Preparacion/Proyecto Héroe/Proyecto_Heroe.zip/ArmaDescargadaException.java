
public class ArmaDescargadaException extends Exception{

    public ArmaDescargadaException(String message) {
        super(message);
    }
}
