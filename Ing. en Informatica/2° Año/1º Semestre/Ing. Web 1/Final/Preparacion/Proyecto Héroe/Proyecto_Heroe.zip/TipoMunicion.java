
public enum TipoMunicion {
    COMUN, EXPLOSIVA, HUMO;
}
