
public interface Guerrero {
    void atacar (Personaje p) throws ArmaDescargadaException;
}
