
public class BolsaLlenaException extends Exception {
    public BolsaLlenaException(String message) {
        super(message);
    }
}
