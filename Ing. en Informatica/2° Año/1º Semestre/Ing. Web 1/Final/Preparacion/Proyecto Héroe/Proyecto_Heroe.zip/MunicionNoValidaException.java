
public class MunicionNoValidaException extends Exception {

    public MunicionNoValidaException(String message) {
        super(message);
    }
}
