
public class Constantes {

	public static final String NL = "\r\n";
	public static final String SEPARADOR = "/";
	
}
