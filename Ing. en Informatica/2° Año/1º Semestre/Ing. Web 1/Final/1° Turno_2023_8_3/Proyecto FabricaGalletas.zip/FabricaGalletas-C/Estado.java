
public enum Estado {
	ENCENDIDO, OCUPADO, APAGADO
}
