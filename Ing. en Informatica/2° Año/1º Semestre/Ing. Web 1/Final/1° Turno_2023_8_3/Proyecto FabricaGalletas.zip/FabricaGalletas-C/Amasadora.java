import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class Amasadora implements Maquina{
	
	private List<Contenedor> contenedores;
    private Estado estado = Estado.APAGADO;
	public Reloj reloj;
	private final String id;
	private Receta receta;
	public int pesoLote=0;
	public static int count;

	/**
	 * Constructor sin parametros
	 * 
	 * Inicializa las variables internas: 
	 * setea el id de la amasadora con el formato "am_"+<count>
	 * setea un nuevo reloj e inicializa la lista de contenedores
	 * incrementea la cuenta total de count
	 */
	public Amasadora(){
		//TODO: implementar
		id=null;
	}
	
	/**
	 * Obtiene un contenedor del ingrediente solicitado conectado a esta Amasadora
	 * 
	 * @param ingrediente el Ingrediente requerido
	 * @return el Contenedor que contiene el ingrediente
	 * @throws ContenedorNoDisponibleException cuando no existe un contenedor del ingrediente solicitado 
	 * 	conectado a la amasadora 
	 */
	public Contenedor getContenedorPara(Ingrediente ingrediente) throws ContenedorNoDisponibleException{
		//TODO: implementar
		return null;
	}
	
	
	
	/**
	 * Extrae una cantidad solicitada del Ingrediente de un contenedor asociado a la Amasadora
	 * 
	 * @param ingrediente el Ingrediente a extraer
	 * @param cantidad la cantidad de ingrediente a extraer
	 * @throws IllegalArgumentException cuando la cantidad es invalida (numero negativo), o cuando no existe
	 * un contenedor del ingrediente especificado asociado a la amasadora
	 */
	public void extraerIngrediente(Ingrediente ingrediente, int cantidad){
		//TODO: implementar
	}
	
		
	/**
	 * Carga una receta en la amasadora. Es posible setear un valor null.
	 * 
	 * @param receta la Receta a cargar
	 * @throws IllegalArgumentException cuando la amasadora no posee contenedor conectado 
	 *   para alguno de los componentes de la receta
	 */
	public void setReceta(Receta receta){
		//TODO: implementar
	}
	
	/**
	 * Obtiene la hora del fin del ciclo de amasado
	 *
	 * @return un Date con la hora del fin del cilco
	 *
	 * Sugerencia: utilice los metodos de la clase Reloj para obtener la hora de Alarma
	 */
	public Date getHoraFinAmasado() {
		//TODO: implementar
		return new Date();
	}
	
	@Override
	/**
	 * Enciende la amasadora, seteando su estado apropiadamente
	 */
	public void encender() {
		//TODO: Implementar
	}

	/**
	 * Apaga la amasadora, seteando su estado apropiadamente
	 * @throws IllegalStateException cuando se quiere apagar una maquina que estada OCUPADA
	 */
	@Override
	public void apagar() {
		//TODO: Implementar
	}

	
	/**
	 * Inicia el proceso de amasado de la receta asociada 
	 * 
	 * - Extrae los ingredientes necesarios para la receta
	 * - Cambia estado de la amasadora a OCUPADO
	 * - Setea la alarma del Reloj de la amasadora al final del ciclo de amasado segun el tiempo 
	 * de amasado de la receta 
	 * - Setea el peso del lote amasado (sumatoria de la cantidad de cada ingrediente de la receta)
	 * 
	 * @throws IllegalStateException cuando 
	 *  . el Estado de la amasadora no es correcto (apagado u ocupado), 
	 *  . no hay receta cargada en la amasadora
	 */
	public void iniciarProceso(){
		//TODO: Implementar
	}	
	
	/**
	 * finaliza el proceso de la maquina
	 *  - Cambia el estado a ENCENDIDO
	 *  - desaloja el lote (pone el peso del lote en cero)
	 *  - limpia la alarma del reloj de la amasadora
	 * 
	 *  @throws IllegalStateException cuando el estado de la maquina esta en estado APAGADO o ENCENDIDO 
	 *  (no hay ningun proceso corriendo)
	 */
	public void finalizarProceso(){
		//TODO: Implementar
	}
	
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	
	/**
	 * Conecta un contenedor a esta amasadora 
	 * @param contenedor el contenedor a conectar
	 */
	public void conectarContenedor(Contenedor contenedor){
		contenedores.add(contenedor);
	}
	
	/**
	 * Desconecta un contenedor de esta amasadora
	 * @param contenedor el contenedor a desconectar
	 */
	public void desconectarContenedor(Contenedor contenedor){
		contenedores.remove(contenedor);
	}
	
	/**
	 * Retorna la lista de contenedores conectados a esta amasadora
	 * @return la lista de contenederes
	 */
	public List<Contenedor> getContenedores(){
		return contenedores;
	}
	
	/**
	 * getter 
	 * @return el estado de esta amasadora
	 */
	public Estado getEstado() {
		return estado;
	}
	
	
	/**
	 * setter
	 * @param estado el estado de la amasadora
	 */
	public void setEstado(Estado estado){
		this.estado=estado;
	}
	
	/**
	 * getter
	 * @return el id de esta amassadora
	 */
	public String getId() {
		return id;
	}
	
	/**
	 * getter
	 * @return la receta asociada a la amasadora
	 */
	public Receta getReceta(){
		return receta;
	}
	
	/**
	 * getter
	 * @return el peso del lote amasado
	 */
	public int getPesoLote(){
		return pesoLote;
	}
	
	@Override
	public boolean equals(Object o){
		if (o instanceof Amasadora){
			return id.equals(((Amasadora) o).id);
		}
		return false;
	}
}

