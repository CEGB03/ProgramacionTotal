public enum TipoDeIngrediente {
    POLVO, LIQUIDO, GRANO
}
