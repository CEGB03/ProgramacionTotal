
public class ContenedorNoDisponibleException extends Exception {

    public ContenedorNoDisponibleException(String s) {
        super(s);
    }

}
