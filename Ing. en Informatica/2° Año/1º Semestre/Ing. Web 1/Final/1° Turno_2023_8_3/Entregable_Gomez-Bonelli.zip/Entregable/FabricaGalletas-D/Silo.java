
public class Silo extends Contenedor {

    /**
     * Constructor de Silo que extiende de Contenedor.
     * @param ingrediente el tipo de ingrediente que almacenará el Silo
     * @param capacidad la capacidad del Silo
     * @throws IllegalArgumentException si el tipo de ingrediente no es POLVO
     */
    public Silo(Ingrediente ingrediente, int capacidad) {
        super(capacidad);
        if (ingrediente.getTipoDeIngrediente() != TipoDeIngrediente.POLVO) {
            throw new IllegalArgumentException("El tipo de ingrediente debe ser POLVO");
        }
        this.ingrediente = ingrediente;
    }

    /**
     * Implementación del método abstracto getIngredienteAlmacenado() de Contenedor.
     * @return el ingrediente almacenado en el Silo.
     */
    @Override
    public Ingrediente getIngredienteAlmacenado() {
        return ingrediente;
    }
}
