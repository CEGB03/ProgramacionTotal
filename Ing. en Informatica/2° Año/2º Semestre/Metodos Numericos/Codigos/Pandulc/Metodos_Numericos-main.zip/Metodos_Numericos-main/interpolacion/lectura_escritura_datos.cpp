
#include <cstdio>



	
	//ejemplo de como escribir en archivo
	/*
	    FILE * file;
        file= fopen("matriz_1.dat", "w");
		
      for(i=0;i<3;i++){
            fprintf(file, "%lf	%lf	%lf	%lf\n", m[i][0],m[i][1],m[i][2],m[i][3]);
        }
        
      */  
	

        
 

